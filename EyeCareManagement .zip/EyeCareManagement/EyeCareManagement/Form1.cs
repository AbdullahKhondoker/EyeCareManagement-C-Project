﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace EyeCareManagement
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\abdul\OneDrive\Documents\HMSdb.mdf;Integrated Security=True;Connect Timeout=30");
        
        private void button1_Click(object sender, EventArgs e) //Login
        {
            if (UserName.Text == "" || Password.Text == "")
            {
                MessageBox.Show("Enter Valid username and Password");
            }
            /*else if (UserName.Text == "Abdullah" || UserName.Text == "Neha" && Password.Text == "abd123" || Password.Text == "neha123")
            {
                MessageBox.Show("Welcome Admin!!");
                Home H = new Home();
                H.Show();
                this.Hide();


            }*/
           
           
            else
            {
                
                 if (RoleCB.SelectedItem.ToString() == "Admin")
                {
                    if (UserName.Text == "Abdullah" || UserName.Text == "Neha" && Password.Text == "abd123" || Password.Text == "neha123")
                    {
                        MessageBox.Show("Welcome Admin!!");
                        Home H = new Home();
                        H.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Name or Password!!If you are not Admin Select Different Role");
                    }
                    
                }
                else if(RoleCB.SelectedItem.ToString() == "Doctor")
                {
                    if (UserName.Text == "Doctor" && Password.Text == "doc123")
                    {
                        MessageBox.Show("Welcome Doctor!!");
                        this.Hide();
                        DiagnosisForm df = new DiagnosisForm();
                        df.Show();
                        
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Name or Password!!If you are not Doctor Select Different Role");
                    }

                }
                else if (RoleCB.SelectedItem.ToString() == "Patient")
                {
                    if (UserName.Text == "Patient" && Password.Text == "pat123")
                    {
                        MessageBox.Show("Welcome Patient!!How Are You Doing Today?");
                        this.Hide();
                        PatientForm2 pf = new PatientForm2();
                        pf.Show();
                        
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Name or Password!!If you are not Patient Select Different Role");
                    }
                    /*DiagnosisForm df = new DiagnosisForm();
                    df.Show();
                    this.Hide();*/
                }
            }
            
            
               
            
            
        }

        private void button2_Click(object sender, EventArgs e) //Clear
        {
            UserName.Text = "";
            Password.Text = "";
            //this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PassCB_CheckedChanged(object sender, EventArgs e)
        {
            if (PassCB.Checked == true)
            {
                Password.UseSystemPasswordChar = true;
            }
            else
            {
                Password.UseSystemPasswordChar = false;
            }
        }
    }
}
