﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace EyeCareManagement
{
    public partial class PatientForm2 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\abdul\OneDrive\Documents\HMSdb.mdf;Integrated Security=True;Connect Timeout=30");
        public PatientForm2()
        {
            InitializeComponent();
        }
        void populatecombo()
        {
            string sql = "select * from DiagnosisTb1";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader rdr;
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("DiagId", typeof(int));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                diag_CB.ValueMember = "DiagId";
                diag_CB.DataSource = dt;

                con.Close();

            }
            catch
            {

            }



        }

        string diagnosis_result;
        string medicine_result;
        string symtom_result;
        string diagnosis_name;
        void fetchInfo()
        {

            con.Open();
            string mysql = "select * from DiagnosisTb1 where DiagId = " + diag_CB.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(mysql, con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                diagnosis_result = dr["Diagnosis"].ToString();
                medicine_result = dr["Medicines"].ToString();
                symtom_result = dr["Symtoms"].ToString();
                diagnosis_name = dr["PatName"].ToString();
                diagnosis_report.Text = diagnosis_result;
                medicine_report.Text = medicine_result;
                symtom_report.Text = symtom_result;
                name_label.Text = diagnosis_name;
            }

            con.Close();

        }

        private void PatientForm2_Load(object sender, EventArgs e)
        {
            populatecombo();
        }

        private void diag_CB_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchInfo();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Are you Sure you want to log out ?");
            Form1 hm = new Form1();
            hm.Show();
            this.Hide();
            
        }
    }
}
