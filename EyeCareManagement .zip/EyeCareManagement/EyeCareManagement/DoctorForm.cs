﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EyeCareManagement
{
    public partial class DoctorForm : Form
    {
        
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\abdul\OneDrive\Documents\HMSdb.mdf;Integrated Security=True;Connect Timeout=30");
        public DoctorForm()
        {
            InitializeComponent(); 
        }
        void populate()
        {
            con.Open();
            String query = "select * from DoctorTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            DoctorGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h1 = new Home();
            h1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Docid.Text == "" || DocName.Text == "" || YearOfExperience.Text == "" || Pass.Text == "")
                MessageBox.Show("Information Submission Missing");
            else
            {
                con.Open();
                string query = "insert into DoctorTb1 values(" + Docid.Text + ",'" + DocName.Text + "','" + YearOfExperience.Text + "','" + Pass.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Successfully Added");
                con.Close();
                populate();
            }
        }

        private void DoctorForm_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Docid.Text == "")
                MessageBox.Show("Enter The Doctor Id!!");
            else
            {
                con.Open();
                string query = "delete from DoctorTb1 where Doc_id = "+Docid.Text+" ";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Doctor Information is Deleted");
                con.Close();
                populate();
            }
        }

        private void DoctorGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >=0)
            {
                DataGridViewRow row = this.DoctorGV.Rows[e.RowIndex];
                Docid.Text = row.Cells["Doc_id"].Value.ToString();
                DocName.Text = row.Cells["Doc_Name"].Value.ToString();
                YearOfExperience.Text = row.Cells["Doc_Exp"].Value.ToString();
                Pass.Text = row.Cells["DocPass"].Value.ToString();

            }
            /*Docid.Text = DoctorGV.SelectedRows[0].Cells[0].Value.ToString();
            DocName.Text = DoctorGV.SelectedRows[0].Cells[1].Value.ToString();
            YearOfExperience.Text = DoctorGV.SelectedRows[0].Cells[2].Value.ToString();
            Pass.Text = DoctorGV.SelectedRows[0].Cells[3].Value.ToString();*/
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "update DoctorTb1 set Doc_Name = '" + DocName.Text + "',Doc_Exp = '"+YearOfExperience.Text+"',DocPass = '"+Pass.Text+"'where Doc_id = "+Docid.Text+" ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Doctor Information Updated!");
            con.Close();
            populate();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void DoctorGV_CellContentClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           /* Docid.Text = DoctorGV.SelectedRows[0].Cells[0].Value.ToString();
            DocName.Text = DoctorGV.SelectedRows[0].Cells[1].Value.ToString();
            YearOfExperience.Text = DoctorGV.SelectedRows[0].Cells[2].Value.ToString();
            Pass.Text = DoctorGV.SelectedRows[0].Cells[3].Value.ToString();*/
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
