﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Collections.Generic;

namespace EyeCareManagement
{    
    public partial class DiagnosisForm : Form
    {
       
        //private Dictionary<string, string> diagnosisMessages = new Dictionary<string, string>();
        public DiagnosisForm()
        {
            InitializeComponent();
            ///instance.this();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\abdul\OneDrive\Documents\HMSdb.mdf;Integrated Security=True;Connect Timeout=30");


        void populatecombo()
        {
            string sql = "select * from PatentTb1";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader rdr;
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("PatID", typeof(int));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                Patid_CB.ValueMember = "PatID";
                Patid_CB.DataSource = dt;

                con.Close();

            }
            catch
            {

            }


        }
      

        string patname;
        void fetchpatientname()
        {

            con.Open();
            string mysql = "select * from PatentTb1 where PatID= " + Patid_CB.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(mysql, con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                patname = dr["PatName"].ToString();
                pat_na.Text = patname;
            }

            con.Close();
            
        }
        
        void populate()
        {
            con.Open();
            String query = "select * from DiagnosisTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            DiagnosisGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Doctor,Are you Sure you want to log out ?");
            Form1 hm = new Form1();
            hm.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (diagnosis_id.Text == ""  || pat_na.Text == "" || symtoms.Text == "" || diagnosis.Text == "" || medicines.Text == "")
                MessageBox.Show("Information Submission Missing");
            else
            {
                con.Open();
                string query = "insert into DiagnosisTb1 values(" + diagnosis_id.Text + "," + Patid_CB.SelectedValue.ToString() + ",'" + pat_na.Text + "','" + symtoms.Text + "','" + diagnosis.Text + "','" + medicines.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Diagnosis Successfully Added");
                con.Close();
                populate();
            }
        }

        private void DiagnosisForm_Load(object sender, EventArgs e)
        {
            populatecombo();
            populate();
        }

        private void Patid_CB_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchpatientname();
        }

        private void Patid_CB_SelectedIndexChanged(object sender, EventArgs e)
        {
            //fetchpatientname();

           
        }

        private void DiagnosisGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DiagnosisGV.Rows[e.RowIndex];
                diagnosis_id.Text = row.Cells["DiagId"].Value.ToString();               
                pat_na.Text = row.Cells["PatName"].Value.ToString();
                symtoms.Text = row.Cells["Symtoms"].Value.ToString();
                diagnosis.Text = row.Cells["Diagnosis"].Value.ToString();
                medicines.Text = row.Cells["Medicines"].Value.ToString();
                Pn_LB.Text = row.Cells["PatName"].Value.ToString();
                Dg_LB.Text = row.Cells["Diagnosis"].Value.ToString();
                Sm_LB.Text = row.Cells["Symtoms"].Value.ToString();
                Med_LB.Text = row.Cells["Medicines"].Value.ToString();
               


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (diagnosis_id.Text == "")
                MessageBox.Show("Enter The Diagnosis Id!!");
            else
            {
                con.Open();
                string query = "delete from DiagnosisTb1 where DiagId = " + diagnosis_id.Text + " ";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Diagnosis Information is Deleted");
                con.Close();
                populate();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "update DiagnosisTb1 set PatId = '"+Patid_CB.SelectedValue.ToString()+"',PatName = '" +pat_na.Text+ "',Symtoms = '" + symtoms.Text + "',Diagnosis = '" +diagnosis.Text+ "', Medicines = '" +medicines.Text+ "'  where DiagId = " +diagnosis_id.Text+ " ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Patient Diagnosis Information Updated!");
            con.Close();
            populate();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(label3.Text , new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Blue, new Point(230));
            e.Graphics.DrawString( Pn_LB.Text + "\n" + Dg_LB.Text + "\n" + Sm_LB.Text + "\n" + Med_LB.Text +"\n" , new Font("Century Gothic", 12, FontStyle.Regular), Brushes.Black, new Point(130,150));
            e.Graphics.DrawString(label9.Text, new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Red, new Point(230,500));
        }

        private void print_btn_Click(object sender, EventArgs e)
        {
            if(printPreviewDialog1.ShowDialog()==DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
        
        
        private void sendButton_Click(object sender, EventArgs e)
        {
            

        }
    }
}
