﻿namespace EyeCareManagement
{
    partial class DiagnosisForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DiagnosisForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.diagnosis_id = new System.Windows.Forms.TextBox();
            this.Patid_CB = new System.Windows.Forms.ComboBox();
            this.symtoms = new System.Windows.Forms.TextBox();
            this.diagnosis = new System.Windows.Forms.TextBox();
            this.medicines = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.DiagnosisGV = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.diagsummary = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.Dg_LB = new System.Windows.Forms.Label();
            this.Med_LB = new System.Windows.Forms.Label();
            this.Sm_LB = new System.Windows.Forms.Label();
            this.Pn_LB = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pat_na = new System.Windows.Forms.TextBox();
            this.print_btn = new System.Windows.Forms.Button();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiagnosisGV)).BeginInit();
            this.diagsummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Purple;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1048, 101);
            this.panel1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(1011, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 23);
            this.label4.TabIndex = 10;
            this.label4.Text = "X";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(287, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(433, 45);
            this.label1.TabIndex = 2;
            this.label1.Text = "Eye Care Diagnosis Section";
            // 
            // diagnosis_id
            // 
            this.diagnosis_id.BackColor = System.Drawing.SystemColors.ControlLight;
            this.diagnosis_id.Location = new System.Drawing.Point(12, 138);
            this.diagnosis_id.Name = "diagnosis_id";
            this.diagnosis_id.Size = new System.Drawing.Size(137, 27);
            this.diagnosis_id.TabIndex = 3;
            this.diagnosis_id.Text = "Diagnosis_id :";
            // 
            // Patid_CB
            // 
            this.Patid_CB.BackColor = System.Drawing.SystemColors.Window;
            this.Patid_CB.FormattingEnabled = true;
            this.Patid_CB.Location = new System.Drawing.Point(12, 185);
            this.Patid_CB.Name = "Patid_CB";
            this.Patid_CB.Size = new System.Drawing.Size(137, 28);
            this.Patid_CB.TabIndex = 8;
            this.Patid_CB.Text = "Patient_id";
            this.Patid_CB.SelectedIndexChanged += new System.EventHandler(this.Patid_CB_SelectedIndexChanged);
            this.Patid_CB.SelectionChangeCommitted += new System.EventHandler(this.Patid_CB_SelectionChangeCommitted);
            // 
            // symtoms
            // 
            this.symtoms.BackColor = System.Drawing.SystemColors.ControlLight;
            this.symtoms.Location = new System.Drawing.Point(173, 138);
            this.symtoms.Name = "symtoms";
            this.symtoms.Size = new System.Drawing.Size(137, 27);
            this.symtoms.TabIndex = 10;
            this.symtoms.Text = "Symtoms";
            // 
            // diagnosis
            // 
            this.diagnosis.BackColor = System.Drawing.SystemColors.ControlLight;
            this.diagnosis.Location = new System.Drawing.Point(173, 186);
            this.diagnosis.Name = "diagnosis";
            this.diagnosis.Size = new System.Drawing.Size(137, 27);
            this.diagnosis.TabIndex = 11;
            this.diagnosis.Text = "Diagnosis";
            // 
            // medicines
            // 
            this.medicines.BackColor = System.Drawing.SystemColors.ControlLight;
            this.medicines.Location = new System.Drawing.Point(173, 239);
            this.medicines.Name = "medicines";
            this.medicines.Size = new System.Drawing.Size(137, 27);
            this.medicines.TabIndex = 12;
            this.medicines.Text = "Medicines";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(12, 285);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 45);
            this.button1.TabIndex = 13;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Purple;
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(133, 285);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(92, 45);
            this.button2.TabIndex = 14;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.Location = new System.Drawing.Point(248, 285);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(92, 45);
            this.button3.TabIndex = 15;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Blue;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Location = new System.Drawing.Point(133, 354);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(92, 45);
            this.button4.TabIndex = 16;
            this.button4.Text = "Log Out";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // DiagnosisGV
            // 
            this.DiagnosisGV.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DiagnosisGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DiagnosisGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DiagnosisGV.Location = new System.Drawing.Point(12, 439);
            this.DiagnosisGV.Name = "DiagnosisGV";
            this.DiagnosisGV.RowHeadersWidth = 51;
            this.DiagnosisGV.RowTemplate.Height = 29;
            this.DiagnosisGV.Size = new System.Drawing.Size(1008, 142);
            this.DiagnosisGV.TabIndex = 17;
            this.DiagnosisGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DiagnosisGV_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Purple;
            this.label2.Location = new System.Drawing.Point(403, 391);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 38);
            this.label2.TabIndex = 18;
            this.label2.Text = "Diagnosis List";
            // 
            // diagsummary
            // 
            this.diagsummary.Controls.Add(this.label9);
            this.diagsummary.Controls.Add(this.Dg_LB);
            this.diagsummary.Controls.Add(this.Med_LB);
            this.diagsummary.Controls.Add(this.Sm_LB);
            this.diagsummary.Controls.Add(this.Pn_LB);
            this.diagsummary.Controls.Add(this.label3);
            this.diagsummary.Location = new System.Drawing.Point(563, 107);
            this.diagsummary.Name = "diagsummary";
            this.diagsummary.Size = new System.Drawing.Size(472, 285);
            this.diagsummary.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.Purple;
            this.label9.Location = new System.Drawing.Point(199, 237);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(191, 28);
            this.label9.TabIndex = 9;
            this.label9.Text = "iCareWeCare Clinic";
            // 
            // Dg_LB
            // 
            this.Dg_LB.AutoSize = true;
            this.Dg_LB.Font = new System.Drawing.Font("Calibri", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Dg_LB.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Dg_LB.Location = new System.Drawing.Point(273, 85);
            this.Dg_LB.Name = "Dg_LB";
            this.Dg_LB.Size = new System.Drawing.Size(79, 21);
            this.Dg_LB.TabIndex = 7;
            this.Dg_LB.Text = "Diagnosis";
            // 
            // Med_LB
            // 
            this.Med_LB.AutoSize = true;
            this.Med_LB.Font = new System.Drawing.Font("Calibri", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Med_LB.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Med_LB.Location = new System.Drawing.Point(273, 178);
            this.Med_LB.Name = "Med_LB";
            this.Med_LB.Size = new System.Drawing.Size(81, 21);
            this.Med_LB.TabIndex = 6;
            this.Med_LB.Text = "Medicines";
            // 
            // Sm_LB
            // 
            this.Sm_LB.AutoSize = true;
            this.Sm_LB.Font = new System.Drawing.Font("Calibri", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Sm_LB.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Sm_LB.Location = new System.Drawing.Point(77, 178);
            this.Sm_LB.Name = "Sm_LB";
            this.Sm_LB.Size = new System.Drawing.Size(76, 21);
            this.Sm_LB.TabIndex = 5;
            this.Sm_LB.Text = "Symtoms";
            // 
            // Pn_LB
            // 
            this.Pn_LB.AutoSize = true;
            this.Pn_LB.Font = new System.Drawing.Font("Calibri", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Pn_LB.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.Pn_LB.Location = new System.Drawing.Point(77, 85);
            this.Pn_LB.Name = "Pn_LB";
            this.Pn_LB.Size = new System.Drawing.Size(107, 21);
            this.Pn_LB.TabIndex = 4;
            this.Pn_LB.Text = "Patient Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("BankGothic Md BT", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(113, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(277, 24);
            this.label3.TabIndex = 3;
            this.label3.Text = "Diagnosis Summary";
            // 
            // pat_na
            // 
            this.pat_na.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pat_na.Location = new System.Drawing.Point(12, 239);
            this.pat_na.Name = "pat_na";
            this.pat_na.Size = new System.Drawing.Size(137, 27);
            this.pat_na.TabIndex = 20;
            this.pat_na.Text = "pat_name:";
            // 
            // print_btn
            // 
            this.print_btn.BackColor = System.Drawing.Color.Blue;
            this.print_btn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.print_btn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.print_btn.Location = new System.Drawing.Point(913, 398);
            this.print_btn.Name = "print_btn";
            this.print_btn.Size = new System.Drawing.Size(92, 35);
            this.print_btn.TabIndex = 21;
            this.print_btn.Text = "Print";
            this.print_btn.UseVisualStyleBackColor = false;
            this.print_btn.Click += new System.EventHandler(this.print_btn_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // DiagnosisForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1047, 586);
            this.Controls.Add(this.print_btn);
            this.Controls.Add(this.pat_na);
            this.Controls.Add(this.diagsummary);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DiagnosisGV);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.medicines);
            this.Controls.Add(this.diagnosis);
            this.Controls.Add(this.symtoms);
            this.Controls.Add(this.Patid_CB);
            this.Controls.Add(this.diagnosis_id);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DiagnosisForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DiagnosisForm";
            this.Load += new System.EventHandler(this.DiagnosisForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DiagnosisGV)).EndInit();
            this.diagsummary.ResumeLayout(false);
            this.diagsummary.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private Label label1;
        private TextBox diagnosis_id;
        private ComboBox Patid_CB;
        private TextBox symtoms;
        private TextBox diagnosis;
        private TextBox medicines;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private DataGridView DiagnosisGV;
        private Label label2;
        private Panel diagsummary;
        private Label label9;
        private Label Dg_LB;
        private Label Med_LB;
        private Label Sm_LB;
        private Label Pn_LB;
        private Label label3;
        private TextBox pat_na;
        private Button print_btn;
        private PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private Label label4;
    }
}