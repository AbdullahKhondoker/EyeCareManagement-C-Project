﻿namespace EyeCareManagement
{
    partial class PatientForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PatientForm2));
            this.diag_CB = new System.Windows.Forms.ComboBox();
            this.diagnosis_report = new System.Windows.Forms.TextBox();
            this.medicine_report = new System.Windows.Forms.TextBox();
            this.symtom_report = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Hello = new System.Windows.Forms.Label();
            this.name_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // diag_CB
            // 
            this.diag_CB.FormattingEnabled = true;
            this.diag_CB.Location = new System.Drawing.Point(50, 119);
            this.diag_CB.Name = "diag_CB";
            this.diag_CB.Size = new System.Drawing.Size(151, 28);
            this.diag_CB.TabIndex = 0;
            this.diag_CB.Text = "Diagnosis ID:";
            this.diag_CB.SelectionChangeCommitted += new System.EventHandler(this.diag_CB_SelectionChangeCommitted);
            // 
            // diagnosis_report
            // 
            this.diagnosis_report.Location = new System.Drawing.Point(50, 186);
            this.diagnosis_report.Name = "diagnosis_report";
            this.diagnosis_report.Size = new System.Drawing.Size(151, 27);
            this.diagnosis_report.TabIndex = 1;
            this.diagnosis_report.Text = "Report :";
            // 
            // medicine_report
            // 
            this.medicine_report.Location = new System.Drawing.Point(50, 254);
            this.medicine_report.Name = "medicine_report";
            this.medicine_report.Size = new System.Drawing.Size(151, 27);
            this.medicine_report.TabIndex = 2;
            this.medicine_report.Text = "Medicine :";
            // 
            // symtom_report
            // 
            this.symtom_report.Location = new System.Drawing.Point(50, 313);
            this.symtom_report.Name = "symtom_report";
            this.symtom_report.Size = new System.Drawing.Size(151, 27);
            this.symtom_report.TabIndex = 3;
            this.symtom_report.Text = "Symtoms :";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(263, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(554, 279);
            this.label1.TabIndex = 4;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.OrangeRed;
            this.label2.Font = new System.Drawing.Font("Bell MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(37, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(177, 33);
            this.label2.TabIndex = 5;
            this.label2.Text = "Patient Form";
            // 
            // Hello
            // 
            this.Hello.AutoSize = true;
            this.Hello.BackColor = System.Drawing.Color.OrangeRed;
            this.Hello.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.Hello.ForeColor = System.Drawing.Color.Black;
            this.Hello.Location = new System.Drawing.Point(50, 425);
            this.Hello.Name = "Hello";
            this.Hello.Size = new System.Drawing.Size(76, 31);
            this.Hello.TabIndex = 6;
            this.Hello.Text = "Hello,";
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Font = new System.Drawing.Font("Segoe UI", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.name_label.Location = new System.Drawing.Point(119, 425);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(0, 31);
            this.name_label.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Symbol", 10.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(50, 467);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(249, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "We are happy to provide sevice";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(811, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 23);
            this.label4.TabIndex = 11;
            this.label4.Text = "X";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(674, 455);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 35);
            this.button1.TabIndex = 12;
            this.button1.Text = "Log Out";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PatientForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OrangeRed;
            this.ClientSize = new System.Drawing.Size(847, 552);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.name_label);
            this.Controls.Add(this.Hello);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.symtom_report);
            this.Controls.Add(this.medicine_report);
            this.Controls.Add(this.diagnosis_report);
            this.Controls.Add(this.diag_CB);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PatientForm2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PatientForm2";
            this.Load += new System.EventHandler(this.PatientForm2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox diag_CB;
        private TextBox diagnosis_report;
        private TextBox medicine_report;
        private TextBox symtom_report;
        private ContextMenuStrip contextMenuStrip1;
        private Label label1;
        private Label label2;
        private Label Hello;
        private Label name_label;
        private Label label3;
        private Label label4;
        private Button button1;
    }
}