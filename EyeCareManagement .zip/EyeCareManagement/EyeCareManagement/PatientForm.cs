﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace EyeCareManagement
{
    public partial class PatientForm : Form
    {
        public PatientForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\abdul\OneDrive\Documents\HMSdb.mdf;Integrated Security=True;Connect Timeout=30");

        void populate()
        {
            con.Open();
            String query = "select * from PatentTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            PatientGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home H2 = new Home();
            H2.Show();
            
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (pat_id.Text == "" || pat_name.Text == "" || pat_address.Text == "" || pat_phone.Text == "" || pat_age.Text == "" || major_disease.Text == "")
                MessageBox.Show("Information Submission Missing");
            else
            {
                con.Open();
                string query = "insert into PatentTb1 values(" + pat_id.Text + ",'" + pat_name.Text + "','" + pat_address.Text + "','" + pat_phone.Text + "','" + pat_age.Text + "',' " + genderCB.SelectedItem.ToString() + " ',' "  + bloodCB.SelectedItem.ToString()  + " ','" + major_disease.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Successfully Added");
                con.Close();
                populate();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.PatientGV.Rows[e.RowIndex];
                pat_id.Text = row.Cells["PatID"].Value.ToString();
                pat_name.Text = row.Cells["PatName"].Value.ToString();
                pat_address.Text = row.Cells["PatAddress"].Value.ToString();
                pat_phone.Text = row.Cells["ParPhone"].Value.ToString();
                pat_age.Text = row.Cells["ParPhone"].Value.ToString();
                pat_phone.Text = row.Cells["PatAge"].Value.ToString();
                major_disease.Text = row.Cells["PatDisease"].Value.ToString();


            }

            /* pat_id.Text = PatientGV.SelectedRows[0].Cells[0].Value.ToString();
            pat_name.Text = PatientGV.SelectedRows[0].Cells[1].Value.ToString();
            pat_address.Text = PatientGV.SelectedRows[0].Cells[2].Value.ToString();
            pat_phone.Text = PatientGV.SelectedRows[0].Cells[3].Value.ToString();
            pat_age.Text = PatientGV.SelectedRows[0].Cells[4].Value.ToString();
            major_disease.Text = PatientGV.SelectedRows[0].Cells[7].Value.ToString();*/

        }

        private void PatientForm_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (pat_id.Text == "")
                MessageBox.Show("Enter The Patient Id!!");
            else
            {
                con.Open();
                string query = "delete from PatentTb1 where patID = " + pat_id.Text + " ";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Information is Deleted");
                con.Close();
                populate();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "update PatentTb1 set PatName = '" + pat_name.Text + "',PatAddress = '" + pat_address.Text + "',ParPhone = '" + pat_phone.Text + "',PatAge = '"+pat_age.Text+"', PatGender = '"+genderCB.SelectedItem.ToString()+"', PatBlood = '"+bloodCB.SelectedItem.ToString()+"',PatDisease= '"+major_disease.Text+"' where PatID = " + pat_id.Text + " ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Patient Information Updated!");
            con.Close();
            populate();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
